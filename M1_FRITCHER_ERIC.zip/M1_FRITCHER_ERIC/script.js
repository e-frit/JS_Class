// Module 1 Practical
document.write("Introduction to Javascript<br>");
console.log("Welcome to Web Scripting with JavaScript".length);
console.log("Eric".toUpperCase());
console.log('       Hello Class!       '.trim());
var string1 = "This week we are learning about:<br>";
var string2 = "JavaScript primative types";
var string3 = "Syntax";
var string4 = "and Output<br>";
var allStrings = string1.concat(" ",string2," ",string3," ",string4);
document.write(allStrings);
console.log(15);
document.write(30+3.5,"<br>");
document.write(2021-1969,"<br>");
document.write(65%240,"<br>");
document.write(0.2708*100,"<br>");
document.write(11/3,"<br>");
console.log(Number(true));
console.log(Number(false));
console.log(Number("2020"));
console.log(Number("College"));
/*if (100>25) alert("100 is larger than 25");
if (17<10) alert("17 is less than 10");
if (26.2===48.3) alert("26.2 and 48.3 are numbers of equal value")*/